
import React, { useState, useEffect } from 'react';
import { CS2Map, TacticalAnalysis, RoundResult, EconomyState } from './types';
import MapCard from './components/MapCard';
import { analyzeTactics } from './services/geminiService';
import { Shield, Target, TrendingUp, Play, ExternalLink, Loader2, Plus, RotateCcw, Youtube, Image as ImageIcon, ChevronRight, Mail, Cpu, Globe, Share2, Check } from 'lucide-react';

const MAPS_DATA = [
  { name: CS2Map.DUST2, url: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=800&q=80' },
  { name: CS2Map.MIRAGE, url: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=800&q=80' },
  { name: CS2Map.INFERNO, url: 'https://images.unsplash.com/photo-1552820728-8b83bb6b773f?auto=format&fit=crop&w=800&q=80' },
  { name: CS2Map.NUKE, url: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=800&q=80' },
  { name: CS2Map.ANCIENT, url: 'https://images.unsplash.com/photo-1540206351-d6465b3ac5c1?auto=format&fit=crop&w=800&q=80' },
  { name: CS2Map.ANUBIS, url: 'https://images.unsplash.com/photo-1469474968028-56623f02e42e?auto=format&fit=crop&w=800&q=80' },
  { name: CS2Map.VERTIGO, url: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=800&q=80' },
  { name: CS2Map.TRAIN, url: 'https://images.unsplash.com/photo-1532102235608-dc8fc689c9ad?auto=format&fit=crop&w=800&q=80' },
];

const App: React.FC = () => {
  const [selectedMap, setSelectedMap] = useState<CS2Map | null>(null);
  const [teamA, setTeamA] = useState<string[]>(['18000', '', '', '', '']);
  const [teamB, setTeamB] = useState<string[]>(['17500', '', '', '', '']);
  const [history, setHistory] = useState<RoundResult[]>([]);
  const [analysis, setAnalysis] = useState<TacticalAnalysis | null>(null);
  const [loading, setLoading] = useState(false);
  const [economy, setEconomy] = useState<EconomyState>('Full');
  const [copied, setCopied] = useState(false);

  const scoreA = history.filter(r => r.winner === 'A').length;
  const scoreB = history.filter(r => r.winner === 'B').length;

  const addRound = (winner: 'A' | 'B') => {
    const newRound: RoundResult = {
      roundNumber: history.length + 1,
      winner,
      ourEconomy: economy,
      enemyEconomy: 'Full'
    };
    setHistory([...history, newRound]);
  };

  const runUpdate = async () => {
    if (!selectedMap) return;
    setLoading(true);
    try {
      const result = await analyzeTactics(selectedMap, teamA.filter(Boolean), teamB.filter(Boolean), history);
      setAnalysis(result);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleShare = () => {
    const url = window.location.href;
    const text = selectedMap 
      ? `CS2 NEXUS 2026 // ${selectedMap.toUpperCase()} // ${scoreA}-${scoreB} // TACTICAL UPLINK: ${url}`
      : `CS2 PREMIER NEXUS // 2026 TACTICAL ADVISOR // ${url}`;
    
    navigator.clipboard.writeText(text).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  useEffect(() => {
    if (history.length > 0 || selectedMap) runUpdate();
  }, [history, selectedMap]);

  return (
    <div className="min-h-screen pb-20 text-slate-200 selection:bg-yellow-500 selection:text-black">
      {/* 2026 Tactical HUD */}
      <div className="sticky top-0 z-[60] bg-black/90 border-b border-white/5 backdrop-blur-3xl">
        <div className="max-w-7xl mx-auto flex items-center justify-between px-6 py-4">
          <div className="flex items-center gap-5">
            <div className="relative group">
              <div className="absolute -inset-1 bg-yellow-500 rounded-lg blur opacity-25 group-hover:opacity-50 transition duration-1000 group-hover:duration-200"></div>
              <div className="relative w-11 h-11 bg-black rounded-lg flex items-center justify-center text-yellow-500 font-black italic text-2xl border border-white/10">CS</div>
            </div>
            <div className="hidden md:block">
              <h1 className="text-base font-black tracking-[0.2em] uppercase bg-gradient-to-r from-white to-white/60 bg-clip-text text-transparent">PREMIER NEXUS</h1>
              <p className="text-[10px] text-yellow-500/80 uppercase tracking-[0.3em] font-bold flex items-center gap-1">
                <Globe size={10} /> 2026 LIVE OPERATIONAL DATA
              </p>
            </div>
          </div>

          <div className="flex-1 flex justify-center">
             <div className="flex items-center gap-6 bg-white/5 px-8 py-2.5 rounded-2xl border border-white/10 shadow-[0_0_40px_-15px_rgba(255,255,255,0.1)]">
               <div className="flex flex-col items-center">
                 <span className="text-[9px] font-black text-blue-400 tracking-widest uppercase mb-0.5">SQUAD ALPHA</span>
                 <span className="text-3xl font-black text-white">{scoreA}</span>
               </div>
               <div className="h-10 w-px bg-white/10 mx-2"></div>
               <div className="flex flex-col items-center">
                 <span className="text-[9px] font-black text-red-400 tracking-widest uppercase mb-0.5">SQUAD OMEGA</span>
                 <span className="text-3xl font-black text-white">{scoreB}</span>
               </div>
             </div>
          </div>

          <div className="flex items-center gap-3">
            <button 
              onClick={handleShare}
              className={`p-2.5 rounded-xl transition-all border flex items-center gap-2 group ${copied ? 'bg-green-500/20 border-green-500/50 text-green-400' : 'bg-white/5 hover:bg-white/10 border-white/5 hover:border-white/10 text-white/40 hover:text-white'}`}
              title="Share Uplink"
            >
              {copied ? <Check size={18} /> : <Share2 size={18} />}
              <span className="hidden sm:inline text-[10px] font-black uppercase tracking-widest">
                {copied ? 'LINK COPIED' : 'SHARE'}
              </span>
            </button>
            <button 
              onClick={() => { setHistory([]); setAnalysis(null); }} 
              className="p-2.5 bg-white/5 hover:bg-white/10 rounded-xl transition-all text-white/40 hover:text-white border border-white/5 hover:border-white/10"
              title="Reset Match"
            >
              <RotateCcw size={18} />
            </button>
          </div>
        </div>
      </div>

      <main className="max-w-7xl mx-auto mt-8 px-6 grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Control Column */}
        <div className="lg:col-span-4 space-y-6">
          <section className="glass-panel rounded-2xl p-5 border border-white/5 shadow-2xl overflow-hidden relative">
            <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none">
              <Cpu size={80} />
            </div>
            <h2 className="text-[11px] font-black uppercase text-white/50 mb-4 flex items-center gap-2 tracking-[0.2em]">
              <Target size={14} className="text-yellow-500" /> ACTIVE MAP POOL
            </h2>
            <div className="grid grid-cols-2 gap-3">
              {MAPS_DATA.map(m => (
                <button 
                  key={m.name} 
                  onClick={() => setSelectedMap(m.name)}
                  className={`relative h-28 rounded-xl overflow-hidden border-2 transition-all duration-500 group ${selectedMap === m.name ? 'border-yellow-500 ring-4 ring-yellow-500/10 scale-[1.02]' : 'border-transparent opacity-60 hover:opacity-100 hover:scale-[1.02]'}`}
                >
                  <img src={m.url} className="w-full h-full object-cover transition-all duration-700 group-hover:scale-110" />
                  <div className={`absolute inset-0 flex items-center justify-center text-[12px] font-black uppercase tracking-widest transition-all ${selectedMap === m.name ? 'bg-black/10 text-white' : 'bg-black/70 text-white/70 group-hover:bg-black/40'}`}>
                    {m.name}
                  </div>
                </button>
              ))}
            </div>
          </section>

          <section className="glass-panel rounded-2xl p-6 border border-white/5 shadow-2xl bg-gradient-to-b from-white/5 to-transparent">
            <h2 className="text-[11px] font-black uppercase text-white/50 mb-5 flex items-center gap-2 tracking-[0.2em]">
              <TrendingUp size={14} className="text-blue-500" /> BATTLESTATE INPUT
            </h2>
            
            <div className="mb-8 space-y-3">
              <div className="flex justify-between items-center">
                <p className="text-[10px] font-black text-white/30 uppercase tracking-widest">NEXT ROUND ECONOMY</p>
                <span className="text-[10px] font-black text-yellow-500 bg-yellow-500/10 px-2 py-0.5 rounded tracking-tighter">ESTIMATED</span>
              </div>
              <div className="grid grid-cols-4 gap-2">
                {(['Eco', 'Force', 'Semi', 'Full'] as EconomyState[]).map(e => (
                  <button 
                    key={e} 
                    onClick={() => setEconomy(e)}
                    className={`py-2.5 text-[10px] font-black rounded-lg border transition-all duration-300 ${economy === e ? 'bg-yellow-500 text-black border-yellow-500 shadow-xl shadow-yellow-500/30 scale-105' : 'bg-white/5 border-white/10 text-white/40 hover:bg-white/10'}`}
                  >
                    {e.toUpperCase()}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <button onClick={() => addRound('A')} className="group py-5 bg-blue-600/10 hover:bg-blue-600/20 border border-blue-500/30 rounded-xl font-black text-xs transition-all uppercase tracking-[0.2em] text-blue-400 shadow-lg shadow-blue-500/5">
                <span className="group-active:scale-95 block transition-transform">ROUND WIN</span>
              </button>
              <button onClick={() => addRound('B')} className="group py-5 bg-red-600/10 hover:bg-red-600/20 border border-red-500/30 rounded-xl font-black text-xs transition-all uppercase tracking-[0.2em] text-red-400 shadow-lg shadow-red-500/5">
                <span className="group-active:scale-95 block transition-transform">ROUND LOSS</span>
              </button>
            </div>
          </section>

          <section className="glass-panel rounded-2xl p-6 border border-white/5 shadow-2xl">
            <h2 className="text-[11px] font-black uppercase text-white/50 mb-4 tracking-[0.2em]">SQUAD MATCHUP (ELO)</h2>
            <div className="flex items-center gap-4">
              <div className="flex-1">
                <p className="text-[10px] font-black text-blue-400/50 mb-2 tracking-tighter">OUR AVG</p>
                <input 
                  type="number" 
                  value={teamA[0]} 
                  onChange={e => setTeamA([e.target.value, ...teamA.slice(1)])} 
                  className="w-full bg-black/40 border border-white/10 rounded-xl p-3 text-sm font-black outline-none focus:border-blue-500/50 transition-all text-white placeholder:text-white/10" 
                />
              </div>
              <div className="text-white/10 mt-6"><ChevronRight size={18} /></div>
              <div className="flex-1">
                <p className="text-[10px] font-black text-red-400/50 mb-2 tracking-tighter">ENEMY AVG</p>
                <input 
                  type="number" 
                  value={teamB[0]} 
                  onChange={e => setTeamB([e.target.value, ...teamB.slice(1)])} 
                  className="w-full bg-black/40 border border-white/10 rounded-xl p-3 text-sm font-black outline-none focus:border-red-500/50 transition-all text-white placeholder:text-white/10" 
                />
              </div>
            </div>
          </section>
        </div>

        {/* Right Tactical Output Column */}
        <div className="lg:col-span-8 space-y-6">
          {loading ? (
            <div className="h-full min-h-[550px] glass-panel rounded-3xl flex flex-col items-center justify-center space-y-8 bg-gradient-to-b from-white/5 to-transparent">
              <div className="relative">
                <div className="w-24 h-24 rounded-full border-t-2 border-yellow-500 animate-spin"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <Cpu size={32} className="text-yellow-500 animate-pulse" />
                </div>
              </div>
              <div className="text-center space-y-2">
                <p className="text-xs font-black text-white uppercase tracking-[0.6em] animate-pulse">Computing Optimal Path</p>
                <p className="text-[11px] text-white/30 uppercase font-medium tracking-widest">Integrating 2026 meta strategies & pro demo data...</p>
              </div>
            </div>
          ) : analysis ? (
            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-700">
              {/* Primary Intel Card */}
              <div className="glass-panel p-10 rounded-[2rem] border-l-8 border-yellow-500 bg-gradient-to-br from-yellow-500/10 via-transparent to-transparent shadow-2xl relative overflow-hidden">
                <div className="absolute -top-10 -right-10 w-40 h-40 bg-yellow-500/10 blur-[100px] pointer-events-none"></div>
                <div className="flex items-center gap-3 mb-8">
                  <div className="w-2.5 h-2.5 rounded-full bg-yellow-500 shadow-[0_0_10px_#facc15]" />
                  <h3 className="text-[11px] font-black text-white/40 uppercase tracking-[0.4em]">LIVE TACTICAL OBJECTIVE</h3>
                </div>
                <p className="text-3xl font-black text-white leading-[1.2] mb-12 tracking-tight">
                  {analysis.matchSummary}
                </p>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {analysis.keyTactics.map((t, i) => (
                    <div key={i} className="group relative p-6 bg-white/[0.03] rounded-2xl border border-white/5 hover:bg-white/[0.08] hover:border-white/10 transition-all duration-500">
                      <div className="absolute top-5 right-6 text-[28px] font-black text-white/[0.02] transition-colors group-hover:text-white/[0.05]">0{i+1}</div>
                      <span className="text-[10px] font-black text-yellow-500 uppercase tracking-[0.2em] block mb-3">PROTOCOL EXECUTION</span>
                      <p className="font-bold text-sm text-white/90 leading-relaxed">{t.action}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Reference Media Section */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                {analysis.visualResources.length > 0 ? (
                  analysis.visualResources.map((res, i) => (
                    <a 
                      key={i} 
                      href={res.uri} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="glass-panel p-6 rounded-2xl border border-white/5 flex items-center gap-5 hover:bg-white/[0.07] transition-all group shadow-xl hover:translate-y-[-2px]"
                    >
                      <div className={`w-16 h-16 rounded-xl bg-black/40 flex items-center justify-center transition-all duration-500 ${res.type === 'video' ? 'text-red-500 group-hover:bg-red-500/20 shadow-[0_0_15px_-5px_rgba(239,68,68,0.5)]' : 'text-blue-400 group-hover:bg-blue-400/20 shadow-[0_0_15px_-5px_rgba(96,165,250,0.5)]'}`}>
                        {res.type === 'video' ? <Youtube size={32} /> : <ImageIcon size={32} />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-[10px] font-black text-white/30 uppercase tracking-[0.2em] mb-1.5">{res.type === 'video' ? 'VIDEO DEBRIEF' : 'TACTICAL MAP'}</p>
                        <p className="text-[13px] font-black text-white truncate group-hover:text-yellow-500 transition-colors leading-tight">{res.title}</p>
                      </div>
                      <ExternalLink size={16} className="text-white/10 group-hover:text-white transition-all" />
                    </a>
                  ))
                ) : (
                  <div className="col-span-2 p-12 text-center glass-panel rounded-2xl border-dashed border-2 border-white/10 opacity-40">
                    <p className="text-xs font-black uppercase tracking-[0.3em] text-white/60">SYNCHRONIZING EXTERNAL ASSETS...</p>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="h-full min-h-[550px] glass-panel rounded-[2.5rem] flex flex-col items-center justify-center text-center p-16 space-y-8 shadow-3xl border border-white/5 relative overflow-hidden group">
              <div className="absolute inset-0 bg-gradient-to-br from-yellow-500/[0.02] to-transparent pointer-events-none"></div>
              <div className="w-28 h-28 rounded-3xl border border-white/10 flex items-center justify-center bg-white/[0.02] shadow-2xl relative transition-transform duration-700 group-hover:scale-105">
                <Target size={48} className="text-white/10" />
                <div className="absolute -inset-2 border border-yellow-500/10 rounded-[2rem] animate-pulse"></div>
              </div>
              <div className="space-y-3 relative">
                <h3 className="text-2xl font-black uppercase tracking-[0.4em] text-white/20">Operational Standby</h3>
                <p className="text-xs text-white/15 max-w-sm mx-auto font-medium leading-relaxed uppercase tracking-wider">
                  System initialized. Select target zone from 2026 Active Duty Pool to begin real-time tactical mapping.
                </p>
              </div>
            </div>
          )}
        </div>
      </main>

      <footer className="mt-24 border-t border-white/5 py-16 bg-black/60 relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-3 gap-12 items-start text-white/20">
          <div className="space-y-4">
            <p className="text-[11px] uppercase font-black tracking-[0.4em] text-white/40">PREMIER NEXUS V6.1.0</p>
            <p className="text-[10px] font-medium tracking-[0.1em] leading-relaxed max-w-xs">
              Autonomous tactical advisory system for high-tier CS2 competitive play. Validated for 2026 Major cycle standards.
            </p>
          </div>
          
          <div className="flex flex-col gap-4 justify-center md:items-center">
             <div className="flex gap-10">
               <span className="text-[10px] font-black uppercase tracking-[0.2em] hover:text-white/60 cursor-default transition-colors">2026 META</span>
               <span className="text-[10px] font-black uppercase tracking-[0.2em] hover:text-white/60 cursor-default transition-colors">GEMINI-3-ULTRA</span>
             </div>
             <p className="text-[9px] font-bold uppercase tracking-[0.5em] text-yellow-500/30">PREMIER READY PROTOCOL</p>
          </div>

          <div className="flex flex-col md:items-end gap-3">
            <p className="text-[11px] font-black uppercase tracking-[0.2em] text-white/40">DIRECT LIAISON</p>
            <a 
              href="mailto:jamesz111666@gmail.com" 
              className="flex items-center gap-3 text-sm font-black text-yellow-500/60 hover:text-yellow-500 transition-all group bg-white/5 px-4 py-2 rounded-xl border border-white/5 hover:border-yellow-500/20 shadow-lg"
            >
              <Mail size={16} className="group-hover:rotate-12 transition-transform" />
              jamesz111666@gmail.com
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
