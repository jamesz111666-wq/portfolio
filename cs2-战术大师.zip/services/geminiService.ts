
import { GoogleGenAI } from "@google/genai";
import { CS2Map, TacticalAnalysis, RoundResult } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const analyzeTactics = async (
  map: CS2Map,
  teamARatings: string[],
  teamBRatings: string[],
  history: RoundResult[]
): Promise<TacticalAnalysis> => {
  const lastRound = history[history.length - 1];
  const scoreA = history.filter(r => r.winner === 'A').length;
  const scoreB = history.filter(r => r.winner === 'B').length;

  const prompt = `
    作为 2026 年 CS2 顶级职业教练（Major 级别视野）。
    当前地图：${map}。
    实时比分：我方 (Alpha) ${scoreA} : 敌方 (Omega) ${scoreB}。
    战局背景：${lastRound ? `上回合结果 [${lastRound.winner === 'A' ? '胜利' : '失败'}]，我方下轮预期经济 [${lastRound.ourEconomy}]，敌方预期 [Full Buy]` : '手枪局/开局第一回合'}。
    双方实力评估：我方均分 ${teamARatings.join("/")}，敌方均分 ${teamBRatings.join("/")}。

    任务指令：
    1. 战局透视：基于 2026 年最新职业比赛 Meta（例如最新的道具配合、站位变体、经济管理逻辑），用一句话（30字内）犀利指出当前最关键的突破点或防守重心。
    2. 核心战术执行：提供 3 个最高效的执行动作指令，每个动作必须言简意赅（15字内），涵盖道具要求或站位时机。
    3. 视觉情报支持：搜索并提供针对 ${map} 的 2026 年最新 YouTube 高端教学、职业哥 POV 或战术示意图（雷达图、道具点位图）的网页链接。

    输出规范：
    - 语言风格：专业、硬核、冷静。
    - 全程中文。
    - 拒绝任何垃圾话或基础介绍，直接给指令。
    - 必须利用 Google Search 插件获取最新（2025下半年-2026年初）的职业比赛数据或攻略。
  `;

  const response = await ai.models.generateContent({
    model: "gemini-3-pro-preview",
    contents: prompt,
    config: {
      tools: [{ googleSearch: {} }],
    },
  });

  const text = response.text || "";
  const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
  
  const resources = groundingChunks.map((chunk: any) => {
    const uri = chunk.web?.uri || "";
    let type: 'video' | 'image' | 'web' = 'web';
    // Enhanced URL detection
    if (uri.includes('youtube.com') || uri.includes('youtu.be') || uri.includes('twitch.tv')) type = 'video';
    else if (uri.match(/\.(jpeg|jpg|gif|png|webp|svg)$/i) != null) type = 'image';
    
    return {
      title: chunk.web?.title || "情报参考",
      uri: uri,
      type
    };
  }).filter(r => r.uri);

  const lines = text.split('\n').filter(l => l.trim().length > 0);
  
  return {
    matchSummary: lines[0]?.replace(/^分析[:：]\s*/, '') || "战术系统已就绪，等待下轮数据...",
    keyTactics: lines.slice(1, 4).map(line => ({
      step: "EXECUTE",
      action: line.replace(/^[\d•-]+\.?\s*/, '')
    })),
    visualResources: resources.slice(0, 4), // Limit to top 4 relevant resources
  };
};
