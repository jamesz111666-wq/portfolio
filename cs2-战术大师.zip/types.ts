
export enum CS2Map {
  MIRAGE = 'Mirage',
  DUST2 = 'Dust II',
  INFERNO = 'Inferno',
  NUKE = 'Nuke',
  ANCIENT = 'Ancient',
  ANUBIS = 'Anubis',
  VERTIGO = 'Vertigo',
  TRAIN = 'Train',
}

export type EconomyState = 'Eco' | 'Force' | 'Semi' | 'Full';

export interface RoundResult {
  roundNumber: number;
  winner: 'A' | 'B';
  ourEconomy: EconomyState;
  enemyEconomy: EconomyState;
}

export interface TacticalAnalysis {
  matchSummary: string;
  keyTactics: {
    step: string;
    action: string;
  }[];
  visualResources: { title: string; uri: string; type: 'video' | 'image' | 'web' }[];
}
