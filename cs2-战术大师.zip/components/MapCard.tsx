
import React from 'react';
import { CS2Map } from '../types';

interface MapCardProps {
  mapName: CS2Map;
  selected: boolean;
  onClick: () => void;
  imageUrl: string;
}

const MapCard: React.FC<MapCardProps> = ({ mapName, selected, onClick, imageUrl }) => {
  return (
    <div 
      onClick={onClick}
      className={`relative cursor-pointer overflow-hidden rounded-xl border-2 transition-all duration-300 group ${
        selected ? 'border-yellow-400 scale-[1.02] shadow-lg shadow-yellow-400/20' : 'border-white/10 hover:border-white/30'
      }`}
    >
      <img src={imageUrl} alt={mapName} className="w-full h-32 object-cover transition-transform duration-500 group-hover:scale-110" />
      <div className={`absolute inset-0 flex items-end p-3 bg-gradient-to-t from-black/80 to-transparent`}>
        <span className="text-white font-bold tracking-wider text-sm">{mapName.toUpperCase()}</span>
      </div>
    </div>
  );
};

export default MapCard;
